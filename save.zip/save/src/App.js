import { Routes, Route, Link } from "react-router-dom";
// import Navbar from "./components/Navbar";
// import About from "./routes/About";
// import Contact from "./routes/Contact";
// import Home from "./routes/Home";
// import Project from "./routes/Project";
import './App.css';
const App = () => {

  return (
    <>

      <div>LOL Company</div>

      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/about">About</Link>
        </li>
        <li>
          <Link to="/project">Project</Link>
        </li>
        <li>
          <Link to="/contact">Contact</Link>
        </li>
        <li>
          <Link to="/dashboard">Dashboard</Link>
        </li>
      </ul>

      <hr />
      <Routes>
        <Route path="/" element={<div>LOL_ok</div>}></Route>
        <Route path="/about" element={<div>oLl</div>}></Route>
        <Route path="/project" element={<div>fsd kotofeJ</div>}></Route>
        <Route path="/contact" element={<div>My soon</div>}></Route>
        <Route path="/dashboard" element={<div>My lon</div>}></Route>
      </Routes>
    </>
  );
};

export default App;
