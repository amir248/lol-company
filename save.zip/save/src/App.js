import { Routes, Route, Link } from "react-router-dom";
import About from "./routes/about";
import Home from "./routes/home";
import Project from "./routes/project";
import Contact from "./routes/contact";
import Gallery from "./routes/photogallery";
// import Language from "./routes/language";
// import './App.css';



const Article = () => {

  return (
    <>

  
      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/about">About</Link>
        </li>
        <li>
          <Link to="/project">Project</Link>
        </li>
        <li>
          <Link to="/contact">Contact</Link>
        </li>
        <li>
          <Link to="/photogallery">Gallery</Link>
        </li>

      </ul>

      <hr />
      <Routes>
        <Route path="/" element={<Home/>}></Route>
        <Route path="/about" element={<About/>}></Route>
        <Route path="/project" element={<Project/>}></Route>
        <Route path="/contact" element={<Contact/>}></Route>
        <Route path="/photogallery" element={<Gallery/>}></Route>
      </Routes>
    </>
  );
};

export default Article;
