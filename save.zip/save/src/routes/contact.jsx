export default function Contact() {
  function language(){
    function randomColor(){
      let colorR=Math.floor(Math.random()*255);
      let colorG=Math.floor(Math.random()*255);
      let colorB=Math.floor(Math.random()*255);
      return (`rgb`+'('+`${colorR}`+","+`${colorG}`+","+`${colorB}`+')');
    }
    document.querySelector('fieldset').style.background=randomColor();
    document.querySelector('legend').style.background=randomColor();
    document.querySelector('legend').style.borderRadius='3px 3px 0 0';
    // document.getElementById('check').addEventListener('click',()=>{
      if(document.querySelector('#check').checked){
        randomColor();
        document.querySelector('fieldset').style.color=randomColor();
        for(let y=0;y<document.querySelectorAll('#eng').length;y++){
          document.querySelectorAll('#eng')[y].style.display="none";
          document.querySelectorAll('#rus')[y].style.display="block";
        }
      }else{
        for(let x=0;x<document.querySelectorAll('#rus').length;x++){
          document.querySelectorAll('#eng')[x].style.display='block';
          document.querySelectorAll('#rus')[x].style.display='none';
        }
      }
    // });
  };
  return(
    <>
    <fieldset>
      <legend>Language</legend>
      <strong> Rus <input type="checkbox" id="check" onClick={language}/></strong>
    </fieldset>
    <h1>Contact</h1>
    <p id='eng'>My phone: <a href='phone:+79528885656'>+79528885656</a> WhatSapp.</p>
    <p id='rus'>телефонама: <a href='phone:+79528885656'>+79528885656</a> Ватсапанама.</p>
    </>
  )
};
