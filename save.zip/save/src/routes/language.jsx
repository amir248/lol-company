export default function Language() {
  function language(){
    document.querySelector('body > main:nth-child(2) > article:nth-child(1) > ul:nth-child(1) > li:nth-child(6) > a:nth-child(1) > input:nth-child(1)').addEventListener('click',()=>{
      console.log('oK');
    });

  }
  return(
    <>
    <h1>Language</h1>
    <p>Languade</p>
    <div onClick={language()}>Language</div>
    </>
  )
};
