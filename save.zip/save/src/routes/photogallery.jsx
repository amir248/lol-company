import One from '../img/DSC_7533.JPG';
import Two from '../img/DSC_7536.JPG';
import Three from '../img/DSC_7537.JPG';
import Four from '../img/DSC_7538.JPG';
import Five from '../img/DSC_7539.JPG';
import Six from '../img/DSC_7540.JPG';
import Seven from '../img/DSC_7555.JPG';
import Eight from '../img/DSC_7561.JPG';
import Nine from '../img/DSC_7562.JPG';
import Ten from '../img/function-return-forever.JPG';

const Array=[One, Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten];

let x=+0;
function lolClick(){
  // document.querySelector('img').addEventListener('click',()=>{
    x++;
    console.log(x);
    document.querySelector('img').setAttribute('src', Array[x]);
    if(x>=Array.length){
      x=0;
      document.querySelector('img').setAttribute('src', Array[x]);
    }
  // });
}

function language(){
  function randomColor(){
    let colorR=Math.floor(Math.random()*255);
    let colorG=Math.floor(Math.random()*255);
    let colorB=Math.floor(Math.random()*255);
    return (`rgb`+'('+`${colorR}`+","+`${colorG}`+","+`${colorB}`+')');
  };
  document.querySelector('fieldset').style.background=randomColor();
  document.querySelector('legend').style.background=randomColor();
  document.querySelector('legend').style.borderRadius='3px 3px 0 0';
  // document.getElementById('check').addEventListener('click',()=>{
    if(document.querySelector('#check').checked){
      randomColor();
      document.querySelector('fieldset').style.color=randomColor();

      for(let y=0;y<document.querySelectorAll('#eng').length;y++){
        document.querySelectorAll('#eng')[y].style.display="none";
        document.querySelectorAll('#rus')[y].style.display="block";
      }
    }else{
      for(let x=0;x<document.querySelectorAll('#rus').length;x++){
        document.querySelectorAll('#eng')[x].style.display='block';
        document.querySelectorAll('#rus')[x].style.display='none';
      }
    }
  // });
};
export default function Gallery() {
  return(
    <>
    <fieldset>
      <legend>Language</legend>
      <strong> Rus <input type="checkbox" id="check" onClick={language}/></strong>
    </fieldset>
    <h1>Gallery LOL</h1>
    <p id='eng'>LOL lol lol.GALLERY LOL</p>
    <p id='rus'>РжуНемогу.</p>
    <img src={ One } alt='LOL' id='img' onClick={lolClick}/>
    </>
  )
};
