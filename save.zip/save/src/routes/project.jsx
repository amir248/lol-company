function language(){
  function randomColor(){
    let colorR=Math.floor(Math.random()*255);
    let colorG=Math.floor(Math.random()*255);
    let colorB=Math.floor(Math.random()*255);
    return `rgb`+'('+`${colorR}`+","+`${colorG}`+","+`${colorB}`+')';
  };
  document.querySelector('fieldset').style.background=randomColor();
  document.querySelector('legend').style.background=randomColor();
  document.querySelector('legend').style.borderRadius='3px 3px 0 0';
  // document.getElementById('check').addEventListener('click',()=>{
    if(document.querySelector('#check').checked){
      randomColor();
      document.querySelector('fieldset').style.color=randomColor();

      for(let y=0;y<document.querySelectorAll('#eng').length;y++){
        document.querySelectorAll('#eng')[y].style.display="none";
        document.querySelectorAll('#rus')[y].style.display="block";
      }
    }else{
      for(let x=0;x<document.querySelectorAll('#rus').length;x++){
        document.querySelectorAll('#eng')[x].style.display='block';
        document.querySelectorAll('#rus')[x].style.display='none';
      }
    }
  // });
};
export default function Project() {
  return(
    <>
    <fieldset>
      <legend>Language</legend>
      <strong> Rus <input type="checkbox" id="check" onClick={language}/></strong>
    </fieldset>
    <h1>Project</h1>
    <p id='eng'>The goals are to create a simple and understandable comment system for easy and quick installation on any site. Like comments. So that it can be very easily and simply embedded in a landing or advertising page with the ability to edit. The comment system is its first page at https://nasobe.ru/comments/</p>
    <p id='rus'>Цели создать простую и понятную системы комментариев для простой и быстрой установки на любые сайте. Как на подобии comments. Чтобы можно было очень легко и просто встроить в лендинг или рекламную страницу с возможностью редактирования. Система комментариев её первая страница в https://nasobe.ru/comments/ </p>
    <iframe width="560" height="315" src="https://www.youtube.com/embed/-EHrIAEUc1Q" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
    </>
  )
};
