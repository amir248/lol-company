import lol from '../img/lol-company.png';
function language(){
  function randomColor(){
    let colorR=Math.floor(Math.random()*255);
    let colorG=Math.floor(Math.random()*255);
    let colorB=Math.floor(Math.random()*255);
    return (`rgb`+'('+`${colorR}`+","+`${colorG}`+","+`${colorB}`+')');
  };
  document.querySelector('fieldset').style.background=randomColor();
  document.querySelector('legend').style.background=randomColor();
  document.querySelector('legend').style.borderRadius='3px 3px 0 0';
  // document.getElementById('check').addEventListener('click',()=>{
    if(document.querySelector('#check').checked){
      randomColor();
      document.querySelector('fieldset').style.color=randomColor();

      for(let y=0;y<document.querySelectorAll('#eng').length;y++){
        document.querySelectorAll('#eng')[y].style.display="none";
        document.querySelectorAll('#rus')[y].style.display="block";
      }
    }else{
      for(let x=0;x<document.querySelectorAll('#rus').length;x++){
        document.querySelectorAll('#eng')[x].style.display='block';
        document.querySelectorAll('#rus')[x].style.display='none';
      }
    }
  // });
};
function header(){
  document.querySelector('head > title').innerHTML='web workshop after baron sajtoverstausen';
  document.querySelector('meta[name="description"]').setAttribute('content','Настоящая веб мастерская имени барона сайтоверстаузена');
  document.querySelector('head > link[rel="canonical"]').setAttribute('href','https://amir248.github.io/lol-company/#/about');
}
export default function About() {
  return(
    <>
    <h1 onLoad={header()}></h1>
    <fieldset>
      <legend>Language</legend>
      <strong> Rus <input type="checkbox" id="check" onClick={language}/></strong>
    </fieldset>
    <h1>About</h1>
    <p id="eng">My name is Amir and I'm a web master!</p>
    <p id="rus">Меня зовут Амир и я веб мастер!</p>

    <p id="eng">And I make websites, landing pages, fast, adaptive pages with SEO optimization and promotion in contextual advertising. And as practice shows, the video on YouTube gives super chic coverage. For example, if you google: <a href='https://www.google.com/search?q=%D0%90%D1%84%D0%B5%D1%80%D0%B0+%D0%B2%D0% B5%D0%BA%D0%B0%2C+%D0%BF%D1%80%D0%B5%D1%81%D1%82%D1%83%D0%BF%D0%BB%D0%B5%D0% BD%D0%B8%D1%8F+%D0%9A%D0%B8%D1%82%D0%B0%D1%8F%21+%D0%9E%D1%81%D1%82%D0%BE%D1 %80%D0%BE%D0%B6%D0%BD%D0%BE+%D0%BA%D0%BE%D0%BC%D0%BC%D1%83%D0%BD%D0%B8%D1%81 %D1%82%21&biw=1280&bih=919&sxsrf=APwXEdfacjq-5KPDJsUF97Dr9IH0hiws-Q%3A1685086916714&ei=xGJwZIiZK875qwHwvJi4Ag&ved=0ahUKEwiIi9j4vZL_Ah XO_CoKHXAeBicQ4dUDCA8&oq=%D0%90%D1%84%D0%B5%D1%80%D0%B0+%D0%B2%D0% B5%D0%BA%D0%B0%2C+%D0%BF%D1%80%D0%B5%D1%81%D1%82%D1%83%D0%BF%D0%BB%D0%B5%D0% BD%D0%B8%D1%8F+%D0%9A%D0%B8%D1%82%D0%B0%D1%8F%21+%D0%9E%D1%81%D1%82%D0%BE%D1 %80%D0%BE%D0%B6%D0%BD%D0%BE+%D0%BA%D0%BE%D0%BC%D0%BC%D1%83%D0%BD%D0%B8%D1%81 %D1%82%21&gs_lcp=Cgxnd3Mtd2l6LXNlcnAQDEoECEEYAFAAWABgAGgAcAF4AIABAIgBAJIBAJgBAA&sclient=gws-wiz-serp'>Scam of the century, crimes of China! Caution: “communist”</a>.
    The first line of the issue is a YouTube video with the scam of the century, the crimes of communist China. Google gives away views and during the trial period, impressions exceeded a thousand views.</p>
    <p id="rus">И я делаю сайты, лендинг пейджи, быстрые, адаптивные страницы с SEO оптимизацией и продвижением в контекстной рекламе. И как показывает практика Видео на ютубе дает сверх шикарный охват. Например если загуглить: <a href='https://www.google.com/search?q=%D0%90%D1%84%D0%B5%D1%80%D0%B0+%D0%B2%D0%B5%D0%BA%D0%B0%2C+%D0%BF%D1%80%D0%B5%D1%81%D1%82%D1%83%D0%BF%D0%BB%D0%B5%D0%BD%D0%B8%D1%8F+%D0%9A%D0%B8%D1%82%D0%B0%D1%8F%21+%D0%9E%D1%81%D1%82%D0%BE%D1%80%D0%BE%D0%B6%D0%BD%D0%BE+%D0%BA%D0%BE%D0%BC%D0%BC%D1%83%D0%BD%D0%B8%D1%81%D1%82%21&biw=1280&bih=919&sxsrf=APwXEdfacjq-5KPDJsUF97Dr9IH0hiws-Q%3A1685086916714&ei=xGJwZIiZK875qwHwvJi4Ag&ved=0ahUKEwiIi9j4vZL_AhXO_CoKHXAeBicQ4dUDCA8&oq=%D0%90%D1%84%D0%B5%D1%80%D0%B0+%D0%B2%D0%B5%D0%BA%D0%B0%2C+%D0%BF%D1%80%D0%B5%D1%81%D1%82%D1%83%D0%BF%D0%BB%D0%B5%D0%BD%D0%B8%D1%8F+%D0%9A%D0%B8%D1%82%D0%B0%D1%8F%21+%D0%9E%D1%81%D1%82%D0%BE%D1%80%D0%BE%D0%B6%D0%BD%D0%BE+%D0%BA%D0%BE%D0%BC%D0%BC%D1%83%D0%BD%D0%B8%D1%81%D1%82%21&gs_lcp=Cgxnd3Mtd2l6LXNlcnAQDEoECEEYAFAAWABgAGgAcAF4AIABAIgBAJIBAJgBAA&sclient=gws-wiz-serp'>Афера века, преступления Китая! Осторожно: “коммунист”</a>.
    Первая строка выдачи это видео на ютубе с аферой века, преступления коммунистического Китая. Гугл отдает просмотры и за пробное время показы перевалили за тысячу просмотров.</p>

    <h2 id="rus">Ютуб шикарен!</h2>
    <h2 id="eng">Youtube is awesome!</h2>

    <img src={lol} alt='видео на ютубе, жирный плюс в рекламе.'/>

    <p id="eng">Therefore, it is worth approaching YouTube videos more carefully, because YouTube is a large niche of potentially necessary characters.</p>
    <p id="rus">Поэтому стоит подходить к видео на ютубе более тщательно ибо ютуб это большая ниша потенциально необходимых персонажей.</p>
    </>
  )
};
