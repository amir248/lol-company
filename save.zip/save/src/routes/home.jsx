import Img from '../img/DSC_7562.JPG';
function language(){
  function randomColor(){
    let colorR=Math.floor(Math.random()*255);
    let colorG=Math.floor(Math.random()*255);
    let colorB=Math.floor(Math.random()*255);
    return `rgb`+'('+`${colorR}`+","+`${colorG}`+","+`${colorB}`+')';
  }
  document.querySelector('fieldset').style.background=randomColor();
  document.querySelector('legend').style.background=randomColor();
  document.querySelector('legend').style.borderRadius='3px 3px 0 0';
  // document.getElementById('check').addEventListener('click',()=>{
    if(document.querySelector('#check').checked){
      randomColor();
      document.querySelector('fieldset').style.color=randomColor();

      for(let y=0;y<document.querySelectorAll('#eng').length;y++){
        document.querySelectorAll('#eng')[y].style.display="none";
        document.querySelectorAll('#rus')[y].style.display="block";
      }
    }else{
      for(let x=0;x<document.querySelectorAll('#rus').length;x++){
        document.querySelectorAll('#eng')[x].style.display='block';
        document.querySelectorAll('#rus')[x].style.display='none';
      }
    }
  // });
};
export default function Home() {
  return(
    <>
      <fieldset>
        <legend>Language</legend>
        <strong> Rus <input type="checkbox" id="check" onClick={language}/></strong>
      </fieldset>

      <p id="eng">Yes, yes, this is a real web workshop. this is a lol company direct advertising of a super company like:</p>
      <p id="rus">Да-да, это настоящая веб-мастерская. это лол компания прямая реклама супер компании типа:</p>

      <h1 id="eng">Web workshop named after Baron Sajtoverstauzen</h1>
      <h1 id="rus">Веб-мастерская имени барона Сайтоверстаузена</h1>

      <img src={Img} alt="web workshop named after Baron Sajtoverstausen"/>
      <p id="eng">The real name is /“web workshop named after Baron Sajtoverstauzen(Барон Сайтоверстаузен)/”. All because it is impossible to work in communism and therefore it would be very fun if a harsh communist trial begins. In which they will accuse the “web workshop named after Baron Siterstauzen” of the real “illegal labor activity”. All because the rat-ridden Moscow “a bunch of scum and war criminals of the Third Reich” comes up with a set of laws called the “living wage” so that not a single person earns a penny to buy a one-way plane ticket. <br/>Now I am like a gloomy wanderer /“a strange and dangerous enemy of the communist state/”, day and night I launch advertising campaigns on adaptive pages promoted with the help of SEO optimization and contextual advertising.</p>
      <p id="rus">Настоящее название — «веб-мастерская имени Барона Сайтоверстаузена (Барон Сайтоверстаузен)». Все потому, что при коммунизме работать невозможно и поэтому было бы очень весело, если бы начался суровый коммунистический суд. В котором обвинят «веб-мастерскую имени барона Ситерштаузена» в настоящей «нелегальной трудовой деятельности». Все потому, что крысиная Москва «кучка подонков и военных преступников Третьего рейха» придумывает свод законов под названием «прожиточный минимум», чтобы ни один человек не зарабатывал ни копейки на покупку билета на самолет в один конец. <br/>Теперь я, как сумрачный скиталец «странный и опасный враг коммунистического государства», день и ночь запускаю рекламные кампании на адаптивных страницах, продвигаемых с помощью SEO-оптимизации и контекстной рекламы.</p>

    </>
  )
};
